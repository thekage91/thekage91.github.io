---
layout: post
title: "La tecnica perfetta per calcolare quanta massa mettere in una teglia di pizza"
author: "Davide"
categories: journal
tags: [cook]
image: pizza.jpg
---

Da appassionato di pizza oramai da anni, ho accumulato una serie di consigli pratici.<br>
Oggi il primo. ☝️ La tecnica perfetta è....<br>

* Prendete la vostra teglia per la pizza
* Misurate la lunghezza dei due lati (espressa in centimetri)
* Calcolate l'area
* Dividete l'area per due
* Et voilà, quello che uscirà fuori sarà il peso esatto della massa da mettere nella teglia.

Facile no?

<br>
<hr>
## Un'ultima cosa ✋ ✋

<form action="https://sprintstudio.us11.list-manage.com/subscribe/post?u=baa6a96ac00514e2d994c55e2&amp;id=10b14f6753" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" validate>
	<legend>Iscriviti nella Newsletter</legend>
	<div class="form-group">
		<input type="text" name="FNAME" class="form-control" id="mce-FNAME" placeholder="Il tuo Nome" required="">
	</div>
	<div class="form-group">
		<input type="email" name="EMAIL" class="form-control required email" id="mce-EMAIL" placeholder="La tua email" required="">
	</div>
	<div class="form-group">
		<input type="checkbox" class="form-check-input" id="mce-MMERGE3" placeholder="Devi dare il consenso" value="SI" name="MMERGE3" required="">
    	<label class="form-check-label" for="mce-MMERGE3" >Ho letto le privacy policy e autorizzo il trattamento dei miei dati</label>
	</div>
	<br>
	<div class="form-group">
		<button type="submit" class="btn btn-default" value="Iscriviti" href="">Iscriviti</button>
	</div>
</form>
