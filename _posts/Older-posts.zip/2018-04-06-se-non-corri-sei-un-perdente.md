---
layout: post
title: "Se non corri sei un perdente"
author: "Davide"
categories: journal
tags: [life]
image: run-run.jpg
---

Una cosa che non ho mai capito nel mondo è la fretta, poi a Londra, capirai!

Da quando mi trovo qui la cosa che mi ha più colpito è come le persone **corrano**, sembra che qualcuno le rincorra e loro sono costrette a scappare, a fuggiere da qualcosa che in realtà sta nella loro testa. <br>Ti travolgono se non ti sposti e non si fanno problemi a risolvere la cosa con un semplice **sorry**, io dentro di me: **sorry il ca°°o**.

Io mi chiedo, perché?<br>
Il brutto è che questa cosa colpisce **tutti**, ma veramente tutti. 

Il neonato corre.

Il bambino corre trascinato dalla mamma che ha fretta.

La mamma corre.

Il ragazzino corre.

Il nonno corre. 

Il cane corre.

Corrono sempre e comunque anche se fuori c'è il sole ed è tutto tranquillo.


La mattina si esce e **si corre**. Si entra in metro e vince chi dice più sorry.

A pranzo, mangiano e corrono, o corrono mangiando, perché no. 

Quando escono da lavoro corrono, nonostante siano appunto usciti da lavoro, quando uno persona normale esclamerebbe: *"aaahhh finalmente!"*, invece qui no. 

L'unico momento in cui non corrono (forse) è quando dormono, ma vai a capire, qualcosa si saranno inventati!


Alla faccia del detto: 
>Chi va piano va sano e va lontano.

Qua se non corri sei un perdente!

