---
layout: post
title: "Ho imparato ad apprezzare il tramonto"
author: "Davide"
categories: life
tags: [life]
image: sunrise.jpg
---

Ho imparato ad apprezzare il tramonto ed i suoi colori. Questa è una cosa nuova per me e mi sta affascinando come se fossi un bambino.

Il momento in cui guardo il sole tramontare e sparire dietro l'orizzonte, è decisamente il momento in cui sono più consapevole e presente.

Consapevole che un altro giorno è passato ed il fatto che il sole stia sparendo ne è la dimostrazione.
La cosa che mi affascina è proprio questa.

Il senso di rilassamento che provo è veramente elevato. Lo riesco a percepire ed è bellissimo.

Durante la giornata è difficilissimo essere così presente e rilassato, ma in quel momento sento che i nervi si rilassano ed il respiro si fa sentire.

Nel momento in cui sono sulla riva ad osservare il tramonto sento scaricarsi tutta la tensione della giornata.

Arriva una valanga di pensieri per distrarmi, ma ho la possibilità di osservarla. Ne prendo le distanze e la lascio andare perché in quel momento il tramonto è più importante e non voglio perdermelo.

Riuscire a far scorrere i pensieri, osservandoli, senza che questi ti condizionino non è facile ma non è impossibile ed io ho deciso di partire dal tramonto per capire come fare.

In questo periodo poi i tramonti sono bellissimi, sarà la temperatura, sarà che è arrivato l'inverno con il freddo, saranno tutta una serie di fattori, ma sono sempre unici.

Ho imparato ad apprezza il tramonto, ma capacitarmi di questa cosa mi da dispiacere.

Mi da dispiacere perché molto spesso abbiamo dietro l'angolo proprio quella cosa che ci potrebbe essere molto utile e non la usiamo.
Diamo valore alle cose belle ed importanti troppo tardi perché veniamo rapiti dal vortice di pensieri dal quale è difficilissimo uscirne.

E' difficilissimo prendere le distanze da questi ed osservarli (e magari salutarli).

Guardare il tramonto mi da proprio questa possibilità, uscire da questo vortice che durante tutta la giornata ti prende e ti porta su e giù senza che te ne accorgi.

Difficilmente riuscirò a non guardare il prossimo tramonto!
